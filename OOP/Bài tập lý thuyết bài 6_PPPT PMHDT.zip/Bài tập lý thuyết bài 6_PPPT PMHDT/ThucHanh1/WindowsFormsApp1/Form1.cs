﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // Danh sách món ăn đã chọn (tên món, số lượng)
        Dictionary<string, int> danhSachMon = new Dictionary<string, int>();

        public Form1()
        {
            InitializeComponent();
        }

        // Khi form load
        private void Form1_Load(object sender, EventArgs e)
        {
            // Thêm bàn vào combobox
            comboBox1.Items.AddRange(new string[] { "Bàn 1", "Bàn 2", "Bàn 3", "Bàn 4" });
            comboBox1.SelectedIndex = 0;

            // Tạo cột cho DataGridView
            dataGridView1.Columns.Add("TenMon", "Tên món");
            dataGridView1.Columns.Add("SoLuong", "Số lượng");

            // Gắn sự kiện click cho các nút nằm trực tiếp trên form
            foreach (Control c in this.Controls)
            {
                if (c is Button btn)
                {
                    // Tránh gắn sự kiện cho các nút chức năng
                    if (btn.Text != "Xóa" && btn.Text != "Order")
                    {
                        btn.Click += BtnMon_Click;
                    }
                }
            }

            // Gắn sự kiện click cho các nút trong groupBox1
            foreach (Control c in groupBox1.Controls)
            {
                if (c is Button btn)
                {
                    if (btn.Text != "Xóa" && btn.Text != "Order")
                    {
                        btn.Click += BtnMon_Click;
                    }
                }
            }
        }

        // Khi nhấn vào button món ăn
        private void BtnMon_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            string tenMon = btn.Text;

            // Nếu món đã tồn tại → tăng số lượng
            if (danhSachMon.ContainsKey(tenMon))
                danhSachMon[tenMon]++;
            else
                danhSachMon[tenMon] = 1;

            CapNhatBang();
        }

        // Hàm cập nhật DataGridView
        private void CapNhatBang()
        {
            dataGridView1.Rows.Clear();
            foreach (var item in danhSachMon)
            {
                dataGridView1.Rows.Add(item.Key, item.Value);
            }
        }

        // Khi nhấn nút Xóa
        private void button16_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string tenMon = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                danhSachMon.Remove(tenMon);
                CapNhatBang();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn món cần xóa!", "Thông báo");
            }
        }

        // Khi nhấn nút Order
        private void button17_Click(object sender, EventArgs e)
        {
            if (danhSachMon.Count == 0)
            {
                MessageBox.Show("Chưa có món nào để order!", "Thông báo");
                return;
            }

            string tenBan = comboBox1.SelectedItem.ToString();
            string fileName = $"Order_{tenBan}_{DateTime.Now:HHmmss}.txt";

            using (StreamWriter sw = new StreamWriter(fileName))
            {
                sw.WriteLine($"Bàn: {tenBan}");
                sw.WriteLine("Danh sách món:");
                foreach (var item in danhSachMon)
                {
                    sw.WriteLine($"{item.Key} - {item.Value}");
                }
            }

            MessageBox.Show($"Đơn hàng đã được ghi vào file:\n{fileName}", "Thành công");
        }

        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void button7_Click(object sender, EventArgs e) { }
        private void button13_Click(object sender, EventArgs e) { }
        private void button14_Click(object sender, EventArgs e) { }
        private void button1_Click(object sender, EventArgs e) { }
    }
}
