﻿using System;
using System.Windows.Forms;

namespace ThucHanh2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Khi bấm nút Thêm
        private void btnThem_Click(object sender, EventArgs e)
        {
            // Kiểm tra rỗng
            if (txtHoTen.Text.Trim() == "")
            {
                MessageBox.Show("Họ tên không được để trống!", "Thông báo");
                txtHoTen.Focus();
                return;
            }

            // Tạo item mới
            ListViewItem item = new ListViewItem(txtHoTen.Text);
            item.SubItems.Add(dtpNgaySinh.Value.ToShortDateString());
            item.SubItems.Add(txtLop.Text);
            item.SubItems.Add(txtDiaChi.Text);

            // Thêm vào listview
            listView1.Items.Add(item);
            ClearInputs();
        }

        // Khi bấm Xóa
        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn sinh viên cần xóa!", "Thông báo");
                return;
            }

            listView1.Items.Remove(listView1.SelectedItems[0]);
        }

        // Khi bấm Sửa
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn sinh viên để sửa!", "Thông báo");
                return;
            }

            ListViewItem item = listView1.SelectedItems[0];
            item.Text = txtHoTen.Text;
            item.SubItems[1].Text = dtpNgaySinh.Value.ToShortDateString();
            item.SubItems[2].Text = txtLop.Text;
            item.SubItems[3].Text = txtDiaChi.Text;

            ClearInputs();
        }

        // Khi chọn 1 dòng listview → hiển thị lên textbox
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
                return;

            ListViewItem item = listView1.SelectedItems[0];
            txtHoTen.Text = item.Text;
            dtpNgaySinh.Value = DateTime.Parse(item.SubItems[1].Text);
            txtLop.Text = item.SubItems[2].Text;
            txtDiaChi.Text = item.SubItems[3].Text;
        }

        // Khi bấm Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Hàm xóa nội dung nhập
        private void ClearInputs()
        {
            txtHoTen.Clear();
            txtLop.Clear();
            txtDiaChi.Clear();
            dtpNgaySinh.Value = DateTime.Now;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
