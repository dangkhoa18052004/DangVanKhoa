﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace QuanLyBanSach
{
    public partial class Form2 : Form
    {
        // 🔧 Chuỗi kết nối
        string strCon = @"Data Source=LAPTOP-37QMD3HF\MSSQLSERVERK;
                          Initial Catalog=QuanLyBanSach;
                          User ID=sa;
                          Password=dangkhoa18052004";

        SqlConnection sqlCon = null;

        public Form2()
        {
            InitializeComponent();
        }

       // 🟩 Khi form load
        private void Form2_Load(object sender, EventArgs e)
        {
            // Cấu hình hiển thị ListView
            lsvDanhSach.View = View.Details;
            lsvDanhSach.FullRowSelect = true;
            lsvDanhSach.GridLines = true;

            // Thêm các cột
            lsvDanhSach.Columns.Add("Mã NXB", 100);
            lsvDanhSach.Columns.Add("Tên NXB", 180);
            lsvDanhSach.Columns.Add("Địa chỉ", 200);

            // Gọi hàm hiển thị dữ liệu
            HienThiDanhSachNXB();
        }

        // 🟢 Hàm mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // 🔴 Hàm đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }


        // 🟡 Hiển thị danh sách NXB
        private void HienThiDanhSachNXB()
        {
            try
            {
                MoKetNoi();

                SqlCommand sqlCmd = new SqlCommand("HienThiNXB", sqlCon);

                sqlCmd.CommandType = CommandType.StoredProcedure;

                SqlDataReader reader = sqlCmd.ExecuteReader();
                lsvDanhSach.Items.Clear();

                while (reader.Read())
                {
                    string maNXB = reader.GetString(0);
                    string tenNXB = reader.GetString(1);
                    string diaChi = reader.GetString(2);

                    ListViewItem lvi = new ListViewItem(maNXB);
                    lvi.SubItems.Add(tenNXB);
                    lvi.SubItems.Add(diaChi);
                    lsvDanhSach.Items.Add(lvi);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị danh sách: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }

        // 🟠 Khi chọn 1 dòng trong ListView
        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0)
                return;

            string maNXB = lsvDanhSach.SelectedItems[0].SubItems[0].Text;
            HienThiThongTinNXBTheoMa(maNXB);
        }

        // 🔵 Hiển thị chi tiết NXB theo mã
        private void HienThiThongTinNXBTheoMa(string maNXB)
        {
            try
            {
                MoKetNoi();

                SqlCommand sqlCmd = new SqlCommand("HienThiChiTietNXB", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@maNXB", maNXB);

                SqlDataReader reader = sqlCmd.ExecuteReader();

                txtMaNXB.Clear();
                txtTenNXB.Clear();
                txtDiaChi.Clear();

                if (reader.Read())
                {
                    txtMaNXB.Text = reader.GetString(0);
                    txtTenNXB.Text = reader.GetString(1);
                    txtDiaChi.Text = reader.GetString(2);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hiển thị chi tiết: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }


        // ⚙️ Thêm hàm này để khắc phục lỗi Designer
        private void txtMaNXB_TextChanged(object sender, EventArgs e)
        {
            // Không cần làm gì cũng được, chỉ để VS Designer không lỗi
        }
    }
}
